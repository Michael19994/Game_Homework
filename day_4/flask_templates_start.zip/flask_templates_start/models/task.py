class Task():

    def __init__(self,title, description, done):
        self.title = title
        self.description = description
        self.done = done
